# iris-flower-prediction
<h1>Overview:</h1>

This project is a web application that uses machine learning to predict the species of an iris flower based on input parameters such as petal length, petal width, sepal length, and sepal width. It uses Flask, a Python web framework, to create a user-friendly interface for making predictions using a trained machine learning classification model.

<h1>Technologies:</h1>

Python (Flask, scikit-learn, pandas)
HTML5, CSS3, Javascript
